package com.program.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.program.dao.EmpDao;
import com.program.entity.Employee;
@Service
public class EmpService {
	@Autowired
	private EmpDao dao;
	
public void addEmp(Employee e) {
	dao.save(e);
	
}
public List<Employee> getAllEmp(){
	return dao.findAll();
	
}
public Employee getEmpById(int id) {
	Optional<Employee> e = dao.findById(id);
	if(e.isPresent()) {
		return e.get();
	}
	return null;
}
public void deleteEmp(int id) {
	dao.deleteById(id);
}
}
